// Place fonts/D2-Clarity-fonts.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: D2-Clarity-fonts
//      fonts:
//       - asset: fonts/D2-Clarity-fonts.ttf
import 'package:flutter/widgets.dart';

class D2_Clarity_fonts {
  D2_Clarity_fonts._();

  static const String _fontFamily = 'D2-Clarity-fonts';

  static const IconData arc = IconData(0xd2c00, fontFamily: _fontFamily);
  static const IconData solar = IconData(0xd2c01, fontFamily: _fontFamily);
  static const IconData void = IconData(0xd2c02, fontFamily: _fontFamily);
  static const IconData stasis = IconData(0xd2c03, fontFamily: _fontFamily);
  static const IconData strand = IconData(0xd2c04, fontFamily: _fontFamily);
  static const IconData barrier = IconData(0xd2c10, fontFamily: _fontFamily);
  static const IconData overload = IconData(0xd2c11, fontFamily: _fontFamily);
  static const IconData unstoppable = IconData(0xd2c12, fontFamily: _fontFamily);
  static const IconData primary = IconData(0xd2c20, fontFamily: _fontFamily);
  static const IconData special = IconData(0xd2c21, fontFamily: _fontFamily);
  static const IconData heavy = IconData(0xd2c22, fontFamily: _fontFamily);
  static const IconData warlock = IconData(0xd2c30, fontFamily: _fontFamily);
  static const IconData hunter = IconData(0xd2c31, fontFamily: _fontFamily);
  static const IconData titan = IconData(0xd2c32, fontFamily: _fontFamily);
  static const IconData arrow = IconData(0xd2c40, fontFamily: _fontFamily);
}
